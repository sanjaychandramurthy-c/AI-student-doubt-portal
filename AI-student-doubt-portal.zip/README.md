# AI Student Doubt Portal

An AI-powered web portal that helps students ask academic questions and receive simple explanations.

## Features

- Student-friendly question interface
- AI-generated answers using the OpenAI API
- Flask backend
- Responsive HTML/CSS frontend
- Easy to extend with OCR, voice input, Tamil-English translation, and teacher dashboard

## Project Structure

```text
AI-student-doubt-portal/
│
├── app.py
├── requirements.txt
├── README.md
├── templates/
│   └── index.html
└── static/
    └── style.css
```

## Setup

### 1. Create a virtual environment

Windows:

```bash
python -m venv venv
venv\Scripts\activate
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Add your API key

Create a file named `.env` in the project folder:

```text
OPENAI_API_KEY=your_api_key_here
OPENAI_MODEL=gpt-4.1-mini
```

Never upload `.env` to GitHub.

### 4. Run the application

```bash
python app.py
```

Open:

```text
http://127.0.0.1:5000
```

## Important

Do not put API keys, passwords, or other secrets directly in your Python source code or GitHub repository.

## Future Enhancements

- OCR for questions from images
- Voice input
- Tamil-English translation
- Student login
- Teacher dashboard
- Question history
- PDF/document question answering
