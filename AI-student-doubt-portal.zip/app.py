import os
from flask import Flask, render_template, request, jsonify
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)

# Optional OpenAI support. The portal still runs without an API key.
try:
    from openai import OpenAI
    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY")) if os.getenv("OPENAI_API_KEY") else None
except Exception:
    client = None


def get_ai_answer(question):
    """Return an AI answer when OPENAI_API_KEY is configured."""
    if not question.strip():
        return "Please enter your question."

    if client is None:
        return (
            "AI service is not configured yet. Add your OPENAI_API_KEY to a .env file "
            "to enable AI-generated answers."
        )

    try:
        response = client.responses.create(
            model=os.getenv("OPENAI_MODEL", "gpt-4.1-mini"),
            input=(
                "You are an AI student doubt assistant. "
                "Explain answers clearly and simply for a college student.\n\n"
                f"Student question: {question}"
            ),
        )
        return response.output_text
    except Exception as e:
        return f"Unable to get an AI response right now: {e}"


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/ask", methods=["POST"])
def ask():
    data = request.get_json(silent=True) or {}
    question = data.get("question", "")
    answer = get_ai_answer(question)
    return jsonify({"answer": answer})


if __name__ == "__main__":
    app.run(debug=True)
